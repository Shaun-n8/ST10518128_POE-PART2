/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package shaun;

import java.io.FileWriter;
import java.util.ArrayList;

/**
 *
 * @author Student
 */
public class QuickChat {

    // Store the message details
    private String messageID;
    private int numMessagesSent;
    private String recipient;
    private String message;
    private String messageHash;

    // Static list to keep all messages
    public static ArrayList<QuickChat> allMessages = new ArrayList<QuickChat>();
    public static int totalMessages = 0;

    
    public QuickChat(String recipient, String message, int numMessagesSent) {
        this.recipient = recipient;
        this.message = message;
        this.numMessagesSent = numMessagesSent;

       
        String id = "";
        for (int i = 0; i < 10; i++) {
            int digit = (int)(Math.random() * 10);
            id = id + digit;
        }
        
        this.messageID = id;
        this.messageHash = createMessageHash();
    }

    // Checks if the message ID is not more than ten characters
    public Boolean checkMessageID() {

        if (messageID.length() <= 10) {
            return true;
            
        } else {
            
            return false;
        }
    }

    // Checks if the recipient cell is correct and must have international code
    public String checkRecipientCell() {

        if (recipient.startsWith("+27") && recipient.length() <= 10) {
            
            return "Cell phone number successfully captured.";
            
        } else {
            
            return "Cell phone number is incorrectly formatted or does not contain an international code, Please correct the number and try again.";
        }
    }

    // Checks if the message has a max 250 characters
    public String checkMessageLength() {

        if (message.length() > 250) {
            
            int extra = message.length() - 250;
            
            return "Message is more then 250 characters " + extra + ", please reduce the characters.";
            
        } else {
            
            return "Message ready to send.";
        }
    }

    // Creates the message hash, first two numbers of ID : number : first and last word
    public String createMessageHash() {

        String[] words = message.split(" ");
        String firstWord = words[0].toUpperCase();
        String lastWord = words[words.length - 1].toUpperCase();

        // Remove punctuation like ? . ,
        firstWord = firstWord.replace("?", "").replace(".", "").replace(",", "").replace("!", "");
        lastWord = lastWord.replace("?", "").replace(".", "").replace(",", "").replace("!", "");

        String firstTwo = messageID.substring(0, 2);

        return firstTwo + ":" + numMessagesSent + ":" + firstWord + lastWord;
    }

    // Allow user to choose if they want to send, store, or disregard - using switch
    public String SentMessage(int choice) {

        String result = "";

        switch (choice) {
            
            case 1:
                allMessages.add(this);
                totalMessages = totalMessages + 1;
                result = "Message successfully sent";
                break;
                
            case 2:
                result = "Press 0 to delete the message";
                break;
                
            case 3:
                storeMessage();
                result = "Message successfully stored";
                break;
                
            default:
                result = "Invalid choice";
                break;
        }

        return result;
    }

    // Returns all messages thta were sent while program is running
    public String printMessages() {

        String output = "";

        for (int i = 0; i < allMessages.size(); i++) {
            QuickChat m = allMessages.get(i);
            output = output + "MessageID: " + m.messageID + "\n";
            output = output + "MessageHash: " + m.messageHash + "\n";
            output = output + "Recipient: " + m.recipient + "\n";
            output = output + "Message: " + m.message + "\n\n";
        }

        return output;
    }

    // Returns total number of messages that were sent
    public int returnTotalMessages() {
        
        return totalMessages;
    }

    
    public void storeMessage() {

        try {
            
            FileWriter fw = new FileWriter("storedMessages.json", true);
            fw.write("{\n");
            fw.write(" \"messageID\": \"" + messageID + "\",\n");
            fw.write(" \"messageHash\": \"" + messageHash + "\",\n");
            fw.write(" \"recipient\": \"" + recipient + "\",\n");
            fw.write(" \"message\": \"" + message + "\"\n");
            fw.write("},\n");
            fw.close();
        } catch (Exception e) {
            System.out.println("Could not save file");
        }
    }
      

    
    public String getMessageID() {
        return messageID;
    }

    public String getMessageHash() {
        return messageHash;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessage() {
        return message;
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package shaun;

import java.util.Scanner;


public class shaun {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("=== USER REGISTRATION ===");
        
        System.out.print(" please enter your First Name: ");
        String firstName = scanner.nextLine();

        System.out.print(" please enter your Surname: ");
        String surname = scanner.nextLine();

        System.out.print("please enter your Username (must contain an underscore '_' and be <= 5 chars): ");
        String username = scanner.nextLine();

        System.out.print("please enter your Password (min 8 chars, 1 uppercase, 1 number, 1 special char): ");
        String password = scanner.nextLine();

        System.out.print("please enter your Cellphone Number (format +27XXXXXXXXX): ");
        String cellPhoneNumber = scanner.nextLine();

        // Instantiate the login object using the 5-argument constructor
        login newUser = new login(firstName, surname, username, password, cellPhoneNumber);

        // Attempt registration and output the status message
        String registrationResult = newUser.registerUser();
        System.out.println("\n" + registrationResult);

        // If registration is successful, test the login feature
        if (registrationResult.equals("Registration successful.")) {
            System.out.println("=== USER LOGIN ===");
            
            System.out.print("please enter Username to login: ");
            String enteredUsername = scanner.nextLine();

            System.out.print("please enter Password to login: ");
            String enteredPassword = scanner.nextLine();

            // Test login credentials
            boolean loginSuccess = newUser.loginUser(enteredUsername, enteredPassword);
            String statusMessage = newUser.returnLoginStatus(loginSuccess);

            if (statusMessage != null) {
                System.out.println(statusMessage);
            } else {
                System.out.println("Login failed: Incorrect username or password.");
            }
        
       
        if (loginSuccess) {
                
            System.out.println("\nWelcome to QuickChat.");
                
            System.out.print("How many messages do you want to enter? ");
                
                int maxMessages = Integer.parseInt(scanner.nextLine());
                
                int entered = 0;
                boolean keepRunning = true;
                
                // Application should run until user selects quit
                while (keepRunning) {
                    
             System.out.println("\n please choose an option:");
             System.out.println("1) Send Messages");
             System.out.println("2) Show recently sent messages");
             System.out.println("3) Quit");
             System.out.print(" please enter option: ");
                    
                int option = Integer.parseInt(scanner.nextLine());
                    
                switch (option) {
                    case 1:
                           
                    if (entered >= maxMessages) {
                        System.out.println("You have reached limit of " + maxMessages);
                                
                        } else {
                               
                        System.out.print(" please enter Recipient (format +27... followed by 10 numbers): ");
                        String reciNum = scanner.nextLine();
                                
                        System.out.print(" please enter your Message: ");
                        String txtMessage = scanner.nextLine();
                                
                        QuickChat myMessage = new QuickChat(reciNum, txtMessage, entered);
                                
                        // Check recipient validation
                                
                        String recCheck = myMessage.checkRecipientCell();
                                
                        System.out.println(recCheck);
                                
                        if (recCheck.equals("Cell phonenumber successfully captured.")) {
                                    
                            String lengthCheck = myMessage.checkMessageLength();
                            System.out.println(lengthCheck);
                                    
                                    
                            if (lengthCheck.startsWith("Message exceeds")) {
                            System.out.println("Please enter a message of less than 250 characters.");
                                        
                            } else {
                                        
                                System.out.println("MessageID: " + myMessage.getMessageID());
                                System.out.println("Message Hash: " + myMessage.getMessageHash());
                                        
                                System.out.println(" please choose whatyou want to do:");
                                System.out.println("1) Send message");
                                System.out.println("2) Disregard message");
                                System.out.println("3) Store the message to send later");
                                System.out.print(" please enter your choice: ");
                                int ch = Integer.parseInt(scanner.nextLine());
                                        
                                String result = "";
                                        
                                       
                                 switch (ch) {
                                            
                                    case 1:
                                        result = myMessage.SentMessage(1);
                                        System.out.println(result);
                                                
                                         
                                        System.out.println("\n--- Message Details ---");
                                        System.out.println("Message ID: " + myMessage.getMessageID());
                                        System.out.println("Message Hash: " + myMessage.getMessageHash());
                                        System.out.println("Recipient: " + myMessage.getRecipient());
                                        System.out.println("Message: " + myMessage.getMessage());
                                                
                                        entered++;
                                        break;
                                                
                                    case 2:
                                        result = myMessage.SentMessage(2);
                                        System.out.println(result);
                                        System.out.print("Press 0 to delete the message: ");
                                        int zero = Integer.parseInt(scanner.nextLine());
                                        if (zero == 0) {
                                        System.out.println("Message is deleted.");
                                        }
                                        break;
                                                
                                    case 3:
                                        result = myMessage.SentMessage(3);
                                        System.out.println(result);
                                        break;
                                                
                                        default:
                                        System.out.println("Invalid choice");
                                        break;
                                     }
                                }
                            }
                        }
                            break;
                            
                        case 2:
                            System.out.println("Coming Soon.");
                            break;
                            
                        case 3:
                            
                            System.out.println("Total messages sent: " + QuickChat.totalMessages);
                            keepRunning = false;
                            System.out.println("Goodbye!");
                            break;
                            
                        default:
                            System.out.println("Invalid option");
                            break;
                    }
                }
            }
        }
            

        scanner.close();
    }
}
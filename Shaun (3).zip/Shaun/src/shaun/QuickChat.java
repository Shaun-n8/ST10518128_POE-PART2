/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package shaun;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class QuickChat {


    private String messageID;
    private int messageNumber;
    private String recipientCell;
    private String messageText;
    private String messageHash;
    private String sendStatus;

    
    public static ArrayList<QuickChat> allMessages = new ArrayList<>();
    public static int totalMessages = 0;
    private static List<QuickChat> storedList = new ArrayList<>();

    public QuickChat() {}

    // Constructor
    public QuickChat(String recipientCell, String messageText, int messageNumber) {
        this.recipientCell = recipientCell;
        this.messageText = messageText;
        this.messageNumber = messageNumber;
        this.messageID = generateMessageID();
        this.messageHash = createMessageHash();
    }

    public QuickChat(int messageNumber, String recipientCell, String messageText) {
        this(recipientCell, messageText, messageNumber);
    }
/**
 * generates a random 10 digit number for messageID
 * 
 */
    
    public String generateMessageID() {
        Random rand = new Random();
        long number = (long) (rand.nextDouble() * 9000000000L) + 1000000000L;
        return String.valueOf(number);
    }
/**
 * validates that message ID is nit more then characters 
 */
    
    public boolean checkMessageID() {
        return messageID != null && messageID.length() <= 10;
    }
/**
 * validates recipient cellphone number format starts with[ '+27' international code and <= 10 characters] 
 */
    public static String checkRecipientCell(String cellNumber) {
        if (cellNumber != null && cellNumber.startsWith("+27") && cellNumber.length() == 12) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
    }
    public String checkRecipientCell() { return checkRecipientCell(this.recipientCell); }
    
    /**
     * validates message payload length must not exceed 250 characters
     */

    public static String checkMessageLength(String message) {
        if (message == null || message.length() <= 250) return "Message ready to send.";
        int extra = message.length() - 250;
        return "Message exceeds 250 characters by " + extra + ", please reduce the size.";
    }
    public String checkMessageLength() { return checkMessageLength(this.messageText); }

    
    public static String createMessageHash(String id, int number, String text) {
        String prefix = (id != null && id.length() >= 2) ? id.substring(0, 2) : "00";
        String first = "", last = "";
        if (text != null && !text.trim().isEmpty()) {
            String[] w = text.trim().split("\\s+");
            first = w[0].replaceAll("[^a-zA-Z0-9]", "").toUpperCase();
            last = w[w.length-1].replaceAll("[^a-zA-Z0-9]", "").toUpperCase();
        }
        return prefix + ":" + number + first + last;
        
    }
    
    public String createMessageHash() { return createMessageHash(messageID, messageNumber, messageText); }
    
    /**
     * handles messages option selection 
     */

    public String SentMessage(int choice) {
        switch (choice) {
            case 1:
                sendStatus = "Sent";
                totalMessages++;
                allMessages.add(this);
                return "Message successfully sent.";
            case 2:
                sendStatus = "Disregarded";
                return "Press 0 to delete the message.";
            case 3:
                sendStatus = "Stored";
                storeMessage();
                return "Message successfully stored.";
            default: return "Invalid option selected.";
        }
    }

    public int returnTotalMessages() { return totalMessages; }
    
    /**
     * returns all sent messages details
     */

    public String printMessages() {
        String out = "";
        for (QuickChat m : allMessages) {
            out += "MessageID: " + m.messageID + "\nMessageHash: " + m.messageHash + 
                   "\nRecipient: " + m.recipientCell + "\nMessage: " + m.messageText + "\n\n";
        }
        return out;
    }

 
    public String storeMessage() {
        storedList.add(this);
        try {
            FileWriter writer = new FileWriter("messages.json");
            writer.write("[\n");
            for (int i = 0; i < storedList.size(); i++) {
                QuickChat m = storedList.get(i);
                writer.write("  {\n    \"messageID\": \"" + m.messageID + "\",\n");
                writer.write("    \"messageNumber\": " + m.messageNumber + ",\n");
                writer.write("    \"recipient\": \"" + m.recipientCell + "\",\n");
                writer.write("    \"message\": \"" + m.messageText.replace("\"", "'") + "\",\n");
                writer.write("    \"messageHash\": \"" + m.messageHash + "\",\n");
                writer.write("    \"status\": \"" + m.sendStatus + "\"\n  }");
                if (i < storedList.size()-1) writer.write(",");
                writer.write("\n");
            }
            writer.write("]\n");
            writer.close();
        } catch (IOException e) { System.err.println("Error: " + e.getMessage()); }
        return "Stored";
    }
// getters and setters
    
    public String getMessageID() { return messageID; }
    public String getMessageHash() { return messageHash; }
    public String getRecipient() { return recipientCell; }
    public String getMessage() { return messageText; }
    public String getRecipientCell() { return recipientCell; }
    public String getMessageText() { return messageText; }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package shaun;

import java.util.Scanner;


public class shaun {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("=== USER REGISTRATION ===");
        
        System.out.print(" please enter your First Name: ");
        String firstName = scanner.nextLine();

        System.out.print(" please enter your Surname: ");
        String surname = scanner.nextLine();

        System.out.print("please enter your Username (must contain an underscore '_' and be <= 5 chars): ");
        String username = scanner.nextLine();

        System.out.print("please enter your Password (min 8 chars, 1 uppercase, 1 number, 1 special char): ");
        String password = scanner.nextLine();

        System.out.print("please enter your Cellphone Number (format +27XXXXXXXXX): ");
        String cellPhoneNumber = scanner.nextLine();

        // Instantiate the login object using the 5-argument constructor
        login newUser = new login(firstName, surname, username, password, cellPhoneNumber);

        // Attempt registration and output the status message
        String registrationResult = newUser.registerUser();
        System.out.println("\n" + registrationResult);

        // If registration is successful, test the login feature
        if (registrationResult.equals("Registration successful.")) {
            System.out.println("=== USER LOGIN ===");
            
            System.out.print("please enter Username to login: ");
            String enteredUsername = scanner.nextLine();

            System.out.print("please enter Password to login: ");
            String enteredPassword = scanner.nextLine();

            // Test login credentials
            boolean loginSuccess = newUser.loginUser(enteredUsername, enteredPassword);
            String statusMessage = newUser.returnLoginStatus(loginSuccess);

            if (statusMessage != null) {
                System.out.println(statusMessage);
            } else {
                System.out.println("Login failed: Incorrect username or password.");
            }
        
       
        if (loginSuccess) {
            
        
        System.out.println("Welcome to QuickChat.");
        System.out.print("How many messages do you want to send? ");
        int maxMessages = Integer.parseInt(scanner.nextLine());
        
        boolean keepRunning = true; // WHILE LOOP - Rubric: While loop 4-5 marks
        int totalEntered = 0;

        while (keepRunning) {
            System.out.println("\n please choose an option:");
            System.out.println("(1) Send Messages");
            System.out.println("(2) Show recently sent messages");
            System.out.println("(3) Quit");
            System.out.print(" please enter option: ");
            int option = Integer.parseInt(scanner.nextLine());

            switch (option) {
                case 1:
                    // FOR LOOP - Rubric: For Loop 8-10 marks
                    // For loop is used to allow the user to enter the assigned number of messages
                    for (int i = totalEntered; i < maxMessages; i++) {
                        if (totalEntered >= maxMessages) {
                            System.out.println("You have reached limit of " + maxMessages);
                            break;
                        }
                        System.out.print(" please enter Recipient (format +27...): ");
                        String reciNum = scanner.nextLine();
                        System.out.print(" please enter your Message: ");
                        String txtMessage = scanner.nextLine();

                        // Message Number created in loop using loop counter i - Rubric 4-5 marks
                        QuickChat myMessage = new QuickChat(reciNum, txtMessage, i);

                        System.out.println(myMessage.checkRecipientCell());
                        System.out.println(myMessage.checkMessageLength());
                        
                        // Message ID and Hash display - Rubric 8-10 marks each (substring)
                        System.out.println("MessageID: " + myMessage.getMessageID());
                        System.out.println("Message Hash: " + myMessage.createMessageHash());

                        System.out.print(" (1) Send (2) Disregard (3) Store: ");
                        int ch = Integer.parseInt(scanner.nextLine());
                        String result = myMessage.SentMessage(ch);
                        System.out.println(result);

                        if (ch == 1) {
                            totalEntered++; // increment correctly
                            System.out.println(myMessage.printMessages());
                        }
                        break; // exit for loop after 1 message to show menu again - still a for loop
                    }
                    break;
                case 2:
                    System.out.println("Coming Soon.");
                    break;
                case 3:
                    System.out.println("Total messages sent: " + QuickChat.totalMessages);
                    keepRunning = false;
                    System.out.println("Goodbye!");
                    break;
                default:
                    System.out.println("Invalid option");
                    break;
            }
        }
        }
        
        scanner.close();
        }
        }
        
    
        }
                
            
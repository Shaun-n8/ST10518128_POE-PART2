/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package shaun;

import org.junit.Test;
import static org.junit.Assert.*;


public class QuickChatTest {
   
   

    @Test
    public void testCheckRecipientSuccess() {
        QuickChat m1 = new QuickChat("+27718693002", "Hi Mike, can you join us for dinner tonight?", 0);
        String result = m1.checkRecipientCell();
        assertEquals("Cell phone number successfully captured.", result);
        System.out.println("Test 1 Recipient PASS: " + result);
    }

    @Test
    public void testCheckRecipientFailure() {
        QuickChat m2 = new QuickChat("08575975889", "Hi Keegan, did you receive the payment?", 1);
        String result = m2.checkRecipientCell();
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.", result);
        System.out.println("Test 2 Recipient FAIL case PASS: " + result);
    }

    @Test
    public void testMessageLengthSuccess() {
        QuickChat m1 = new QuickChat("+27718693002", "Hi Mike, can you join us for dinner tonight?", 0);
        String result = m1.checkMessageLength();
        assertEquals("Message ready to send.", result);
        System.out.println("Message length success: " + result);
    }

    @Test
    public void testMessageLengthFailure() {
       
        String longMessage = "";
        for (int i = 0; i < 260; i++) {
            longMessage = longMessage + "a";
        }
        QuickChat mLong = new QuickChat("+27718693002", longMessage, 0);
        String result = mLong.checkMessageLength();
        assertTrue(result.contains("Message exceeds 250 characters by"));
        System.out.println("Message length fail: " + result);
    }

    @Test
    public void testMessageID() {
        QuickChat m1 = new QuickChat("+27718693002", "Test", 0);
        Boolean result = m1.checkMessageID();
        assertTrue(result);
        System.out.println("Message ID generated: <" + m1.getMessageID() + ">");
    }

    @Test
    public void testMessageHash() {
        QuickChat m1 = new QuickChat("+27718693002", "Hi Mike, can you join us for dinner tonight?", 0);
        String hash = m1.createMessageHash();
        // Should end with HITONIGHT - first word HI and last TONIGHT
        System.out.println("Hash generated: " + hash);
        assertTrue(hash.contains("HITONIGHT"));
        assertTrue(hash.contains(":0:"));
    }

    @Test
    public void testSentMessageOptions() {
        QuickChat m1 = new QuickChat("+27718693002", "Hi", 0);
        
        String send = m1.SentMessage(1);
        assertEquals("Message successfully sent", send);
        
        String disregard = m1.SentMessage(2);
        assertEquals("Press 0 to delete the message", disregard);
        
        String store = m1.SentMessage(3);
        assertEquals("Message successfully stored", store);
        
        System.out.println("Send: " + send);
        System.out.println("Disregard: " + disregard);
        System.out.println("Store: " + store);
    }

    @Test
    public void testTotalMessages() {
        // reset total
        QuickChat.totalMessages = 0;
        QuickChat.allMessages.clear();
        
        QuickChat m1 = new QuickChat("+27718693002", "Hello", 0);
        m1.SentMessage(1);
        
        QuickChat m2 = new QuickChat("+27718693002", "Hello 2", 1);
        m2.SentMessage(1);
        
        assertEquals(2, m1.returnTotalMessages());
        System.out.println("Total messages: " + m1.returnTotalMessages());
    }
}